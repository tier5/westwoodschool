
var $j = jQuery.noConflict();

$j(document).ready(function() {
	"use strict";

	var img1 = '<img class="right-il" src="http://westwoodschool.org/wp-content/uploads/2016/08/ib-world-school-logo-2-colour.png">';
jQuery('.header_bottom .container_inner').append(img1);});
