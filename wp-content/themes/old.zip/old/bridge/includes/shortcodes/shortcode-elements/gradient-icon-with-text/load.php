<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/gradient-icon-with-text/gradient-icon-with-text.php';