<a itemprop="url" class="ql_full_link" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"></a>
<div class="post_content_holder">
    <i class="link_mark icon_paperclip"></i>
    <div class="post_text">
        <div class="post_text_inner">
            <div class="post_title entry_title">
                <p><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></p>
            </div>
        </div>
    </div>
</div>